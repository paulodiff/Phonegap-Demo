﻿MyApp.home = function (params) {

    var viewModel = {
//  Put the binding properties here
		messaggio: ko.observable('Gestione posizione gps'),
		titolo: 'Titolo',
		actionSavePosition: function(){},
		actionFindPosition: function(){},
		actionCompass: function(){
			MyApp.app.navigate('compass');
		}
		
    };

    return viewModel;
};